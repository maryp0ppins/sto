'use client'
import Wizard from './Wizard'

export default function RecordNewPage() {
  return (
    <div className="flex flex-col items-center py-8">
      <Wizard />
    </div>
  )
}
