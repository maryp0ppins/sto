// общий контракт для ВСЕХ шагов мастера
import type { WizardContext } from './types'

export type OnNext = (patch?: Partial<WizardContext>) => void

export interface StepProps {
  context: Partial<WizardContext>
  onNextAction: OnNext
}
